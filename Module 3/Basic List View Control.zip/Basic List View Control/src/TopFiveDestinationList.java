import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {

        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(1200, 1050);  // changed to fit my screen better

        listModel = new DefaultListModel();


        //Make updates to your top 5 list below. Import the new image files to resources directory.
        addDestinationNameAndPicture("1. Honolulu, Hawaii, USA \n The largest city in the state of Hawaii, on the " +
                        "island of O'ahu.",
                new ImageIcon(getClass().getResource("/resources/honolulu.jpg"))); // pixabay.com, Artist: 12019
        addDestinationNameAndPicture("2. London, England \n The largest city in the United Kingdom, located in " +
                        "Southern England.",
                new ImageIcon(getClass().getResource("/resources/london.jpg"))); // pixabay.com, Artist: 12019
        addDestinationNameAndPicture("3. Anaheim, California, USA \n A popular vacation spot, home to Disneyland, in " +
                        "Orange County, California.",
                new ImageIcon(getClass().getResource("/resources/anaheim.jpg"))); // pixabay.com, Artist: pixellava
        addDestinationNameAndPicture("4. CanCun, Mexico \n A beautiful city located in Eastern Mexico along the " +
                        "Caribbean Sea.",
                new ImageIcon(getClass().getResource("/resources/cancun.jpg"))); // pixabay.com, Artist: nextvoyage
        addDestinationNameAndPicture("5. Paris, France \n The largest city in France, located in the northern half of" +
                        " France.",
                new ImageIcon(getClass().getResource("/resources/paris.jpg"))); // pixabay.com, Artist: nuno_lopez
        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(25);

        list.setCellRenderer(renderer);

        JLabel nameLabel = new JLabel("Name: Bryce Jensen");  // Label with my name

        // sets nameLabel text details
        getContentPane().add(nameLabel, BorderLayout.NORTH);
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 28));

        getContentPane().add(scrollPane, BorderLayout.CENTER);

        list.setBackground(Color.GRAY);
        list.setSelectionBackground(Color.ORANGE);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        list.setFont(new Font("Arial",Font.BOLD,28));  // added to renderer because my with my HiDPI screen the font
        // was about 3 pixels tall and nearly impossible to read, change back to '14' for the default size.


        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}